"""A module for types to use during io for Compounds and GAPs. These types are not specialized for a model, but
instead aim to be easy to interact with while containing the information necessary for the model"""
