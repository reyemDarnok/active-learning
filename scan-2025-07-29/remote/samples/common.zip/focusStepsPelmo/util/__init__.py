"""A module for various helper functions"""
